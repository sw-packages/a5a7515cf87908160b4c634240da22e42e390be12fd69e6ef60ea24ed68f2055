//
// TCPServerParams.h
//
// Library: Net
// Package: TCPServer
// Module:  TCPServerParams
//
// Definition of the TCPServerParams class.
//
// Copyright (c) 2005-2007, Applied Informatics Software Engineering GmbH.
// and Contributors.
//
// SPDX-License-Identifier:	BSL-1.0
//


#ifndef Net_TCPServerParams_INCLUDED
#define Net_TCPServerParams_INCLUDED


#include "Poco/Net/Net.h"
#include "Poco/RefCountedObject.h"
#include "Poco/Timespan.h"
#include "Poco/Thread.h"
#include "Poco/AutoPtr.h"
#include <cstddef>


namespace Poco {
namespace Net {


class Net_API TCPServerParams: public Poco::RefCountedObject
	/// This class is used to specify parameters to both the
	/// TCPServer, as well as to TCPServerDispatcher objects.
	///
	/// Subclasses may add new parameters to the class.
{
public:
	using Ptr = Poco::AutoPtr<TCPServerParams>;

	TCPServerParams();
		/// Creates the TCPServerParams.
		///
		/// Sets the following default values:
		///   - threadIdleTime:       10 seconds
		///   - maxThreads:           0
		///   - maxQueued:            64

	void setThreadIdleTime(const Poco::Timespan& idleTime);
		/// Sets the maximum idle time for a thread before
		/// it is terminated.
		///
		/// The default idle time is 10 seconds;

	const Poco::Timespan& getThreadIdleTime() const;
		/// Returns the maximum thread idle time.

	void setMaxQueued(int count);
		/// Sets the maximum number of queued connections.
		/// Must be greater than 0.
		///
		/// If there are already the maximum number of connections
		/// in the queue, new connections will be silently discarded.
		///
		/// The default number is 64.

	int getMaxQueued() const;
		/// Returns the maximum number of queued connections.

	void setMaxThreads(int count);
		/// Sets the maximum number of simultaneous threads
		/// available for this TCPServerDispatcher.
		///
		/// Must be greater than or equal to 0.
		/// If 0 is specified, the TCPServerDispatcher will
		/// set this parameter to the number of available threads
		/// in its thread pool.
		///
		/// The thread pool used by the TCPServerDispatcher
		/// must at least have the capacity for the given
		/// number of threads.

	int getMaxThreads() const;
		/// Returns the maximum number of simultaneous threads
		/// available for this TCPServerDispatcher.

	void setThreadPriority(Poco::Thread::Priority prio);
		/// Sets the priority of TCP server threads
		/// created by TCPServer.

	Poco::Thread::Priority getThreadPriority() const;
		/// Returns the priority of TCP server threads
		/// created by TCPServer.
	//reactor
	bool getReactorMode() const;
		/// Returns the reactor mode.
		///
		/// If true, use reactor mode, else use thread pool mode.
	void setReactorMode(bool reactorMode);
		/// Sets the reactor mode.
		///
		/// If true, use reactor mode, else use thread pool mode.
	int getAcceptorNum() const;
		/// Returns the number of acceptors.

	void setAcceptorNum(int acceptorNum);
		/// Sets the number of acceptors.
		///
		/// The number of acceptors must be greater than 0.
		/// The default is 1.

	bool getUseSelfReactor() const;
		/// Returns true if acceptor's self reactor is used.
		
	void setUseSelfReactor(bool useSelfReactor);
		/// Sets the acceptor's self reactor.
		///
		/// If true, use acceptor's self reactor, else create {_maxThreads} threads to use

	const Poco::Timespan& getSendTimeout() const;
		/// Returns the send timeout applied to accepted connections in reactor
		/// mode. Zero (the default) means no timeout.

	void setSendTimeout(const Poco::Timespan& timeout);
		/// Sets a send timeout on accepted connections (reactor mode only).
		///
		/// In reactor mode HTTP handlers write the response on the reactor
		/// thread over a blocking socket. Without a send timeout a client that
		/// stops reading (suspended laptop, zero TCP window) blocks that thread
		/// forever, permanently wedging the worker reactor and every connection
		/// multiplexed onto it. A non-zero send timeout turns that into a
		/// TimeoutException that closes the stuck connection instead.
		///
		/// Zero (the default) preserves the historical no-timeout behavior.

	std::size_t getMaxPendingRequestSize() const;
		/// Returns the maximum size of a not yet completely received request,
		/// in bytes.

	void setMaxPendingRequestSize(std::size_t size);
		/// Sets the maximum number of bytes buffered per connection while a
		/// request is still incomplete; a connection exceeding it is closed.
		/// Default 10 MB, 0 disables the limit. Reactor mode only.
		///
		/// The same buffer holds the request body, so the limit must cover the
		/// largest body the server is expected to accept.

protected:
	virtual ~TCPServerParams();
		/// Destroys the TCPServerParams.

private:
	Poco::Timespan _threadIdleTime;
	int _maxThreads;
	int _maxQueued;
	Poco::Thread::Priority _threadPriority;

	bool _reactorMode;
	int _acceptorNum;
	bool _useSelfReactor;
	Poco::Timespan _sendTimeout;
	std::size_t _maxPendingRequestSize;
};


//
// inlines
//
inline const Poco::Timespan& TCPServerParams::getThreadIdleTime() const
{
	return _threadIdleTime;
}


inline int TCPServerParams::getMaxThreads() const
{
	return _maxThreads;
}


inline int TCPServerParams::getMaxQueued() const
{
	return _maxQueued;
}


inline Poco::Thread::Priority TCPServerParams::getThreadPriority() const
{
	return _threadPriority;
}


inline const Poco::Timespan& TCPServerParams::getSendTimeout() const
{
	return _sendTimeout;
}


inline void TCPServerParams::setSendTimeout(const Poco::Timespan& timeout)
{
	_sendTimeout = timeout;
}


inline std::size_t TCPServerParams::getMaxPendingRequestSize() const
{
	return _maxPendingRequestSize;
}


inline void TCPServerParams::setMaxPendingRequestSize(std::size_t size)
{
	_maxPendingRequestSize = size;
}


} } // namespace Poco::Net


#endif // Net_TCPServerParams_INCLUDED
